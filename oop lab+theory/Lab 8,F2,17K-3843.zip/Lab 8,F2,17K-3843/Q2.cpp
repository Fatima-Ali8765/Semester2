#include <iostream>
using namespace std;
class PrimeNumber{
	private:
		int num;
	public:
		PrimeNumber()
		{
			num=1;
		}
		PrimeNumber(int x)
		{
			num=x;
		}
		int getpri()
		{
			return num;
		}
		
		PrimeNumber operator++(int){
			int nextprime=num;
			do{
				nextprime++;
			}while(!isPrime(nextprime));
			return PrimeNumber(nextprime);
		}
		
		PrimeNumber operator--(int){
			int previousprime=num;
			do{
				previousprime--;
				if(previousprime<1)
				{return PrimeNumber(1);
				}
			}while(!isPrime(previousprime));
			return PrimeNumber(previousprime);
		}
		bool isPrime(int num);
};
bool PrimeNumber::isPrime(int num){
			for(int q=num-1;q>1;q--)
			if(num%q==0)
			return false;
			return true;
		}
int main()
{
	PrimeNumber p1(13),p2;
	cout<<"Initial values:\n";
	cout<<p1.getpri()<<endl;
	cout<<p2.getpri()<<endl;
	PrimeNumber p3=p2++;
	cout<<"Value of prime1:\n";
	cout<<p3.getpri()<<endl;
	PrimeNumber p4=p1++;
	cout<<"Value of prime:\n";
	cout<<p4.getpri()<<endl;
	PrimeNumber p5=p1--;
	cout<<"Value of prime:\n";
	cout<<p5.getpri()<<endl;
}
