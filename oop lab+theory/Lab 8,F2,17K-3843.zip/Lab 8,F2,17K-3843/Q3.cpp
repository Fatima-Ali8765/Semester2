#include <iostream>
using namespace std;
class Time{
	private:
		int hours, minutes, seconds;
	public:
		Time(int h=0,int m=0,int s=0)
		{
			hours=h;
			minutes=m;
			seconds=s;
		}
		void printTime()
		{
			cout<<"Hours: "<<hours<<endl;
			cout<<" Minutes: "<<minutes<<endl;
			cout<<" Seconds: "<<seconds<<endl;
		}
		Time operator+(Time &obj){
			Time temp;
			temp.hours=obj.hours+hours;
			temp.minutes=obj.minutes+minutes;
			temp.seconds=obj.seconds+seconds;
			if(temp.seconds>60)
			{
				temp.seconds=temp.seconds-60;
				temp.minutes=temp.minutes+1;
			}
			if(temp.minutes>60)
			{
				temp.minutes=temp.minutes-60;
				temp.hours=temp.hours+1;
			}
			return temp;
		}
};
int main()
{
	Time obj1(1,20,20),obj2(3,5,6);
	Time time;
	cout<<"time of obj1:\n";
	obj1.printTime();
	cout<<"time of obj2:\n";
	obj2.printTime();
	time=obj1+obj2;
	cout<<"Time:\n";
	time.printTime();
}
