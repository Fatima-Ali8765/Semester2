#include <iostream>
using namespace std;
class Location{
	private:
		int latitude,longitude;
	public:
		Location(int latit=0,int longitu=0){
			latitude=latit;
			longitude=longitu;
		}
		virtual void Display()const{
			cout<<"Latitude: "<<latitude<<endl;
			cout<<"Longitude: "<<longitude;
		}
		Location &operator++(){
			latitude++;
			longitude++;
			return *this;
		}
		Location operator++(int){
			Location temp=*this;
			latitude++;
			longitude++;
			return temp;
		}
		Location operator+(int x)const
		{
			Location temp;
			temp.latitude=latitude+x;
			temp.longitude=longitude+x;
			return temp;
		}
		friend Location operator+(int value,const Location &obj7);
};
Location operator+(int value,const Location &obj7)
{
	Location temp;
	temp.latitude=obj7.latitude+value;
	temp.longitude=obj7.longitude+value;
	return temp;
}
class Details: public Location{
	private:
		string address;
	public:
		Details(string add=""){
			address=add;
		}
		virtual void Display()const
		{
			cout<<endl<<"Address: "<<address;
		}
};
int main()
{
	Details details("Lahore");
	Location obj1(10,20),obj2(5,30),obj3(90,90);
	cout<<endl<<"Location of obj1: ";
	obj1.Display();
	cout<<endl<<"Location of obj2: ";
	obj2.Display();
	cout<<endl<<"Location of obj3: ";
	obj3.Display();
	details.Display();
	++obj1;
	cout<<endl<<"Preincrement result of obj1: "<<endl;
	obj1.Display();
	obj2=obj1++;
	cout<<endl<<"Postincrement result of obj1: "<<endl;
	obj2.Display();
	obj2=obj1+10;
	cout<<endl<<"(keeping 10 the operand on right hand side),the result for obj2\n";
	obj2.Display();
	obj2=10+obj1;
	cout<<endl<<"(keeping 10 the operand on left hand side),the result for obj2\n";
	obj2.Display();
	obj1=obj2=obj3;
	cout<<endl<<"Location of obj1: \n";
	obj1.Display();
	cout<<endl<<"Location of obj2: \n";
	obj2.Display();
	cout<<endl<<"Location of obj3: \n";
	obj3.Display();
	cout<<"Address through pointer:\n";
	Location *p1;
	p1=&details;
	p1->Display();
	return 0;
}
