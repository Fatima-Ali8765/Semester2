#include<iostream>
using namespace std;
class Account{
	protected:
		double Balance;
	public:
		Account()
		{
			Balance=0;
		}
		Account(double a)
		{
			Balance=a;
		}
		void Deposit(double amo)
		{
			Balance=Balance+amo;
		}
		double Withdraw()
		{
			double with_draw;
			cout<<"Enter the amount to withdraw: ";
			cin>>with_draw;			
			if(with_draw>Balance)
			{
				with_draw=0;
				cout<<"Withdraw amount is greater than the balance in account";
			}
			Balance=Balance-with_draw;
			return Balance;
		}
		void checkbalance(){
			cout<<"Your balance is: "<<Balance<<endl;
		}
};
class InterestAccount:virtual public Account{
	private:
		float interest;
	public:
		InterestAccount()
		{
			interest=0.3;
		}
		InterestAccount(double c):Account(c)
		{
			interest=0.3;
		}
		Deposit(double amount)
		{
			cout << "Amount Deposited: " << amount << " with interest of 30% "<< endl;
			Balance =Balance+((amount*interest)+amount);
		}
};
class ChargingAccount:virtual public Account{
	private:
		int fee;
	public:
		ChargingAccount()
		{
			fee=3;
		}
		ChargingAccount(double a):Account(a)
		{
			fee=3;
		}
		 Withdraw(double with)
		{
			cout<<"Withdraw amount: "<<with<<" and -$3 as a withdrawal fee"<<endl;
			with=with+fee;
			Balance=Balance-with;
		}
};
class ACI:public InterestAccount,public ChargingAccount{
	public:
		ACI(double v):InterestAccount(v),ChargingAccount(v)
		{
			Balance=v;
		}
		ACI():InterestAccount(0),ChargingAccount(0){
		}
	transfer(double amount,Account &account){
			if(Balance - amount >= 0){
				Balance -= amount;
				account.Deposit(amount);
			}
			else
				cout << "Insufficient balance.";
		}
		transfer(double amount, InterestAccount &InterestAcc){
			if(Balance - amount >= 0){
				Balance -= amount;
				InterestAcc.Deposit(amount);
			}
			else
				cout << "Insufficient balance.";	
		}
		transfer(double amount, ChargingAccount &ChargingAcc){
			if(Balance - amount >= 0){
				Balance -= amount;
				ChargingAcc.Deposit(amount);
			}
			else
				cout << "Insufficient balance.";
		}
};
int main()
{
	int num,n1;
	double bal,j,dep,with;
	Account acc;
	InterestAccount inter;
	ChargingAccount charg;
	cout<<"                   MENU\n1.Deposit\n2.Withdraw\n3.Transfer\n";
	cin>>num;
	switch(num){
		case 1:
			{
				cout<<"Enter the balance: ";
				cin>>bal;
				InterestAccount inter(bal);
				cout<<"Enter the amount to deposit: ";
				cin>>dep;
				inter.Deposit(dep);
				inter.checkbalance();
				break;
			}
		case 2:
			{
				cout<<"Enter the balance: ";
				cin>>bal;
				ChargingAccount charg(bal);
				cout<<"Enter the amount to withdraw: ";
				cin>>with;
				charg.Withdraw(with);
				charg.checkbalance();
				break;
			}
		case 3:
			{
				cout<<"      Transfer Money to\n1.Account\n2.Interest Account\n3.Charging Account";
				cin>>n1;
				switch(n1)
				{
					case 1:
						{
							cout<<"Enter the balance: ";
							cin>>bal;
							cout<<"Enter the amount to transfer: ";
							cin>>j;
							ACI trat(bal);
							trat.transfer(j,acc);
							trat.checkbalance();
							acc.checkbalance();
							break;
						}
					case 2:
						{
							cout<<"Enter the balance: ";
							cin>>bal;
							cout<<"Enter the amount to transfer: ";
							cin>>j;
							ACI trat(bal);
							trat.transfer(j,inter);
							trat.checkbalance();
							inter.checkbalance();
							break;
						}
					case 3:
						{
							cout<<"Enter the balance: ";
							cin>>bal;
							cout<<"Enter the amount to transfer: ";
							cin>>j;
							ACI trat(bal);
							trat.transfer(j,charg);
							trat.checkbalance();
							charg.checkbalance();
							break;
						}
				}
				
			}
			break;
			
	}
}
