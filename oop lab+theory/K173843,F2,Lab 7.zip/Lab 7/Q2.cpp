#include <iostream>
using namespace std;
class Vehicle{
	private:
		string typeofcar,Make,Model,Color;
		int Year;
		float milesdriven;
	public:
		Vehicle(string typecar,string mak,string mod,string col,int yea,float mildri):typeofcar(typecar),Make(mak),Model(mod),Color(col),Year(yea),milesdriven(mildri){
		}
		void display()
		{
			cout<<"Type of car: "<<typeofcar<<endl;
			cout<<"Make: "<<Make<<endl;
			cout<<"Model: "<<Model<<endl;
			cout<<"Color: "<<Color<<endl;
			cout<<"Year: "<<Year<<endl;
			cout<<"Miles driven:"<<milesdriven<<endl;
		}
};
class GasVehicle:virtual public Vehicle{
	private:
		float fulltanksize;
	public:
		GasVehicle(string typecar,string mak,string mod,string col,int yea,float mildri,float ftanksize):Vehicle(typecar,mak,mod,col,yea,mildri),fulltanksize(ftanksize){
		}
		void dis2()
		{
			cout<<"Size of tank: "<<fulltanksize<<endl;
		}
};
class ElectricVehicle:virtual public Vehicle{
	private:
	float EnergyStorage;
	public:
		ElectricVehicle(string typecar,string mak,string mod,string col,int yea,float mildri,float E):Vehicle(typecar,mak,mod,col,yea,mildri),EnergyStorage(E){
		}
		void dis3()
		{
			cout<<"Energy Storage: "<<EnergyStorage<<endl;
		}
};
class HeavyVehicle:public GasVehicle, public ElectricVehicle{
	private:
		float maxweight,length;
		int noOfWheels;
	public:
		HeavyVehicle(string typecar,string mak,string mod,string col,int yea,float mildri,float E,float ftanksize,float mw,float leth,int now):ElectricVehicle(typecar,mak,mod,col,yea,mildri,E),GasVehicle(typecar,mak,mod,col,yea,mildri,ftanksize),Vehicle(typecar,mak,mod,col,yea,mildri),maxweight(mw),length(leth),noOfWheels(now){
		}
		void dis4()
		{
			cout<<"Maximum weight: "<<maxweight<<endl;
			cout<<"Length: "<<length<<endl;
			cout<<"Number of wheels: "<<noOfWheels<<endl;
		}
};
class HighPerformance:public GasVehicle{
	private:
		float horsepower,topspeed;
	public:
		HighPerformance(string tcar,string Mak,string Mod,string C,int Y,float m,float ftanksize,float hp,float ts):GasVehicle(tcar,Mak,Mod,C,Y,m,ftanksize),Vehicle(tcar,Mak,Mod,C,Y,m),horsepower(hp),topspeed(ts){
		}
};
class SportsCar:public HighPerformance{
	private:
		string gearbox,drivesystem;
	public:
		SportsCar(string tcar,string Mak,string Mod,string C,int Y,float m,float ftanksize,float hp,float ts,string gb,string ds):HighPerformance(tcar,Mak,Mod,C,Y,m,ftanksize,hp,ts),Vehicle(tcar,Mak,Mod,C,Y,m),gearbox(gb),drivesystem(ds){
		}
};
class ConstructionTruck:public HeavyVehicle{
	private:
		string cargo;
	public:
		ConstructionTruck(string tcar,string Mak,string Mod,string C,int Y,float m,float E,float ftanksize,float mw,float leth,int now,string cgo):HeavyVehicle(tcar,Mak,Mod,C,Y,m,E,ftanksize,mw,leth,now),Vehicle(tcar,Mak,Mod,C,Y,m),cargo(cgo){
		}
};
class Bus:public HeavyVehicle{
	private:
		int noOfseats;
	public:
		Bus(string tcar,string Mak,string Mod,string C,int Y,float m,float E,float ftanksize,float mw,float leth,int now,int nos):HeavyVehicle(tcar,Mak,Mod,C,Y,m,E,ftanksize,mw,leth,now),noOfseats(nos),Vehicle(tcar,Mak,Mod,C,Y,m){
		}
		void dis5()
		{
			display();
			dis2();
			dis3();
			dis4();
			cout<<"Number of seats: "<<noOfseats;
		}
};
int main()
{
	Bus obj("SUV","CHEVROLET","LIMO","WHITE",2007,45.3,78,561,400,8.2,4,6);
	obj.dis5();
}
