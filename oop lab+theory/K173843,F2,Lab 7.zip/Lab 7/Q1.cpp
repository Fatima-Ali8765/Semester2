#include <iostream>
using namespace std;
class Employee{
	protected:
		string name,code;
	public:
		Employee(string h,string x):name(h),code(x){
		}
};
class Consultant:virtual public Employee{
	protected:
		int yearsOfExperience;
	public:
		Consultant(int y,string h,string x):yearsOfExperience(y),Employee(h,x){
		}
};
class Manager:virtual public Employee{
	protected:
		int noOfTeams;
	public:
		Manager(int n,string h,string x):noOfTeams(n),Employee(h,x){
		}
};
class ConsultantManager:public Manager,public Consultant{
	public:
		ConsultantManager(string h,string x,int n,int y):Consultant(y,h,x),Manager(n,h,x),Employee(h,x){
		}
		void Display(){
				cout<<endl<<name;
				cout<<endl<<code;
				cout<<endl<<noOfTeams;
				cout<<endl<<yearsOfExperience;
			}
};
int main()
{
	ConsultantManager obj("Ali","S-123",17,5);
	obj.Display();
	return 0;
}
