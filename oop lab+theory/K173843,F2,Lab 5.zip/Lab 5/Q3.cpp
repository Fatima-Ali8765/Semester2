#include <iostream>
#include<math.h>
using namespace std;
class BankAccount{
	private:
		string namedepositor,acctype;
		int accountnum;
		static float rateofinterest;
		float balanceamount;
	public:
		BankAccount(string nm,string at,int acn,float balanceamo)
		{
			namedepositor=nm;
			acctype=at;
			accountnum=acn;
			balanceamount=balanceamo;
		}
		static void ROI()
		{
			float amt,years;
			cout<<"\nEnter number of years: ";
			cin>>years;
			amt=pow((1+rateofinterest),years);
			cout<<"Rate of interest: "<<amt;
		}
		void display(){
			cout<<endl<<"Account number: "<<accountnum;
			cout<<endl<<"Name: "<<namedepositor;
			cout<<endl<<"Account type: "<<acctype;
			cout<<endl<<"Balance: "<<balanceamount;
		}
		void deposit(){
			float amt;
			cout<<"\nEnter amount to deposit: ";
			cin>>amt;
			balanceamount=balanceamount+amt;
			cout<<"Amount deposited is: "<<balanceamount;
		}
		float withdraw(){
			float amo;
			cout<<"\nEnter amount to withdraw: ";
			cin>>amo;
			balanceamount=balanceamount-amo;
			cout<<"Amount after withdrawal is: "<<balanceamount;
		}
};
float BankAccount::rateofinterest = 0.08;
int main()
{
	string s,at;
	int an,c;
	float val;
	cout<<"Enter Account no.: ";
	cin>>an;
	cout<<"Enter Name: ";
	cin>>s;
	cout<<"Enter Account type: ";
	cin>>at;
	cout<<"Enter your balance amount in your account: ";
	cin>>val;
	BankAccount bin(s,at,an,val);
	do
	{
	cout<<"\n1.Deposit amount\n2.Withdraw amount\n3.Display account details\n4.Display rate of interest\n5.Exit\n";
	cout<<"Enter your choice: ";
	cin>>c;
	switch(c)
	{
		case 1:
			bin.deposit();
			break;
		case 2:
			bin.withdraw();
			break;
		case 3:
			bin.display();
			break;
		case 4:
			bin.ROI();
			break;
		default:
			break;
	}
	}while(c!=5);
}
