#include <iostream>
using namespace std;
class Employee{
	private:
		char* EmployeeName;
		const int Employeeid;
	public:
		Employee(int x):Employeeid(x)
		{
		}
		void set_name(char* o)
		{
			EmployeeName=o;
		}
		char* get_name()
		{
			return EmployeeName;
		}
		void display()
		{
			cout<<endl<<get_name();
			cout<<endl<<Employeeid;
		}
		
};
int main()
{
	int u;
	char* x=new char;
	char* y=new char;
	char* z=new char;
	cout<<"Enter number of first employee: ";
	cin>>u;	
	Employee Employee1(u);
	cout<<"Enter name: ";
	cin>>x;
	Employee1.set_name(x);
	cout<<"Enter number of second employee: ";
	cin>>u;
	Employee Employee2(u);
	cout<<"Enter name: ";
	cin>>y;
	Employee2.set_name(y);
	cout<<"Enter number of third employee: ";
	cin>>u;
	Employee Employee3(u);
	cout<<"Enter name: ";
	cin>>z;
	Employee3.set_name(z);
	Employee1.display();
	Employee2.display();
	Employee3.display();
}
