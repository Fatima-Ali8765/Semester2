#include <iostream>
using namespace std;
class RentCalculator{
	private:
		int numberofDays;
		float customerRent;
		const float rentPerDay=1000.85;
		const string customerName;
	public:
		RentCalculator(string s,int n):customerName(s)
		{
			numberofDays=n;
		}
		void RentWithBonus()
		{
			if(numberofDays>7)
			{
			customerRent=rentPerDay*(numberofDays-1);	
			}
			else if(numberofDays==7)
			{
			customerRent=rentPerDay*(numberofDays);
			}
			else
			{
			RentWithoutBonus();
			}
		}
		void RentWithoutBonus()
		{
			customerRent=rentPerDay*(numberofDays);
		}
	    void DisplayRent()
	    {
	    	cout<<endl<<"CustomerName: "<<customerName;
	    	cout<<endl<<"Days: "<<numberofDays;
	    	cout<<endl<<"Rent: "<<customerRent;
		}	
};
int main()
{
		int n;
		string Name;
		cout<<"Enter the name of first employee: ";
		cin>>Name;
		cout<<"Enter the number of days of first employee: ";
		cin>>n;
		RentCalculator c1(Name,n);
		c1.RentWithBonus();
		c1.DisplayRent();
		cout<<"Enter the name of second employee: ";
		cin>>Name;
		cout<<"Enter the number of days of second employee: ";
		cin>>n;
		RentCalculator c2(Name,n);
		c2.RentWithBonus();
		c2.DisplayRent();
}
