#include <iostream>
using namespace std;
int main()
{
	int val,n;
	cout<<"Enter the amount: ";
	cin>>val;
	cout<<"The possible banknotes are: "<<endl;
	n=val/100;
	cout<<n<<" Notes of 100."<<endl;
	val=val-(n*100);
	n=val/50;
	cout<<n<<" Notes of 50."<<endl;
	val=val-(n*50);
	n=val/20;
	cout<<n<<" Notes of 20."<<endl;
	val=val-(n*20);
	n=val/10;
	cout<<n<<" Notes of 10."<<endl;
	val=val-(n*10);
	n=val/5;
	cout<<n<<" Notes of 5."<<endl;
	val=val-(n*5);
	n=val/2;
	cout<<n<<" Notes of 2."<<endl;
	val=val-(n*2);
	n=val/1;
	cout<<n<<" Notes of 1."<<endl;
	return 0;	
}
