#include <iostream>
using namespace std;
/*Program to calculate product of three numbers*/
int main()
{
	int x,y,z,result;
	cout<<"The program is to calculate product of three integers."<<endl;
	cout<<"Enter the first number for calculation: ";
	cin>>x;
	cout<<"Enter the second number for calculation: ";
	cin>>y;
	cout<<"Enter the third number for calculation: ";
	cin>>z;
	result=x*y*z;
	cout<<"The product is "<<result;
	return 0;
}
