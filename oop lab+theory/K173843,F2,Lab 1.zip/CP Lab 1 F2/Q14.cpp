#include <iostream>
using namespace std;
int main()
{
	int x,y,n;
	cout<<"Enter the first value: ";
	cin>>x;
	cout<<"Enter the second value: ";
	cin>>y;
	cout<<"Enter the value of n: ";
	cin>>n;
	if(n>0)
	cout<<"The value after addition is: "<<x+y;
	else if(n<=0)
	cout<<"The value after subtraction is: "<<x-y;
}
