#include <iostream>
using namespace std;
void swap_floats(float *x,float *y)
{
	float swap_temp;
	swap_temp=*x;
	*x=*y;
	*y=swap_temp;
}
int main()
{
	float x=5.8,y=0.9;
	swap_floats(&x,&y);
	cout<<"float numbers after swapping are: "<<x<<" "<<y;
}
