#include <iostream>
using namespace std;
int main()
{
	int mn;
	cout<<"Enter month number ";
	cin>>mn;
	if(mn%2!=0)
	cout<<"The number of days is 31";
	else if(mn%2==0 && mn!=2)
	cout<<"The number of days is 30";
	else
	cout<<"The number of days is 28";
}
