#include <iostream>
using namespace std;
int main()
{
	int q,x=4,m=0,arr[5];
	cout<<"Enter a number ";
	cin>>q;
	while(q!=0)
	{
		arr[x]=q%10;
		arr[x]+=1;
		x--;
		q/=10;
	}
	for(x=0;x<5;x++)
	{
		m=m*10+arr[x];
	}
	cout<<m;
}
