#include <iostream>
using namespace std;
int main()
{
	int n=100,x=0;
	while(x!=5)
	{
		cout<<n<<"\n";
		n/=2;
		x++;
		if(x==5)
		break;
		cout<<n<<"\n";
		n+=2;
		x++;
	}
}
