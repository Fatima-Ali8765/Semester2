#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	int n=2,x;
	for(x=1;x<6;x++)
	{
	cout<<n<<",";
	n=n+pow(2,x+1);
	}
}
