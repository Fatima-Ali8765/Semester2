#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	int n,x;
	float average,tot=0,val;
	cout<<"Enter the number of courses: ";
	cin>>n;
	for(x=1;x<=n;x++)
	{
		cout<<"Enter marks obtained in course "<<x<<":";
		cin>>val;
		tot=tot+val;
	}
	average=tot/n;
	cout<<"Average marks of "<<n<<" courses:"<<fixed<<setprecision(4)<<average;
	return 0;
}
