#include <iostream>
using namespace std;
int main()
{
	int a,b,c,d,tot,den;
	char e;
	cout<<"Enter first fraction: ";
	cin>>a>>e>>b;
	cout<<"Enter Second fraction: ";
	cin>>c>>e>>d;
	tot=a*d+b*c;
	den=b*d;
	cout<<"Sum: "<<tot<<"/"<<den;
	return 0;
}
