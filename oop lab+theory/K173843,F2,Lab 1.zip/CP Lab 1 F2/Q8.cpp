#include <iostream>
using namespace std;
int main()
{
	int a,r=1,b,x,rem;
	cout<<"Enter the number of guests and available seats: ";
	cin>>a>>b;
	rem=a-b;
	for(x=a;x>rem;x--)
	r=r*x;
	cout<<"Number of arrangements: "<<r;
	return 0;
}
