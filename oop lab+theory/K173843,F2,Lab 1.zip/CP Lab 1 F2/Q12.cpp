#include <iostream>
using namespace std;
int main()
{
	char a[9][10]={"ONE","TWO","THREE","FOUR","FIVE","SIX","SEVEN","EIGHT","NINE"};
	char b[10][10]={"ELEVEN","TWELVE","THIRTEEN","FOURTEEN","FIFTEEN","SIXTEEN","SEVENTEEN","EIGHTEEN","NINETEEN"};
	char c[10][10]={"TEN","TWENTY","THIRTY","FOURTY","FIFTY","SIXTY","SEVENTY","EIGHTY","NINETY"};
	int x,t,length=0;
	cout<<"Enter any number betwen 1 and 9999: ";
	cin>>x;
	t=x;
	while(t!=0)
	{
		t/=10;
		length++;
	}
	if(x<9999 && (length==4 || length==3))
	{
	if(x>1000)
		{
		t=x/1000;
		cout<<a[t-1]<<" THOUSAND ";
		x=x%1000;
		}
	if(x>100)
		{
		t=x/100;
		cout<<a[t-1]<<" HUNDRED ";
		x%=100;
		}
	if(x>=10 && x<20)
		{
		t=x/10;
		cout<<"AND "<<b[t-1];
		}
	if(x>19 && x<=100)
		{
		t=x/10;
		cout<<"AND "<<c[t-1];
		x=x%10;
		}
	if(x<10 && x!=0)
		{
		cout<<" "<<a[x-1];
		}
	}
	else if(x<100 && (length==2 || length==1))
	{
		if(x>19 && x<=100)
		{
		t=x/10;
		cout<<c[t-1];
		x=x%10;
		}
	if(x<10)
		{
		cout<<" "<<a[x-1];
		}
	}
	return 0;
}
