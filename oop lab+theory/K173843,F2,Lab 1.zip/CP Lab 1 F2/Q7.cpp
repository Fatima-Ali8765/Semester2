#include <iostream>
using namespace std;
int main()
{
	float i,j,v;
	char op;
	cout<<"Enter a number, an operator (either '+' to add,'-' to subtract ,'/' to divide or '*' to multiply) and another number for calculation: ";
	cin>>i>>op>>j;
	switch(op)
	{
		case '/':
			v=i/j;
			break;
		case '*':
			v=i*j;
			break;
		case '+':
			v=i+j;
			break;
		case '-':
			v=i-j;
			break;
		default:
			cout<<"You have entered an incorrect operator.";
			break;
	}
	cout<<"Result: "<<v;
}
