#include <iostream>
using namespace std;
class Fraction{
	protected:
		int numerator,denominator;
	public:
		Fraction(int n,int d){
			numerator=n;
			denominator=d;
		}
		Fraction(){
			numerator=0;
			denominator=0;
		}
		int getnumerator()
		{
			return numerator;
		}
		int getdenominator()
		{
			return denominator;
		}
		Fraction Add(Fraction &obj){
			int n1,n2,d1,d2;
			char ch;
			cout<<"enter a fraction to add: ";
			cin>>n1>>ch>>n2;
			d1=obj.getnumerator()*n2+n1*obj.getdenominator();
			d2=obj.getdenominator()*n2;
			Fraction obj2(d1,d2);
			return obj2;
		}
		Fraction Subtract(Fraction &obj){
			int n1,n2,d1,d2;
			char ch;
			cout<<"enter a fraction to Subtract: ";
			cin>>n1>>ch>>n2;
			d1=obj.getnumerator()*n2-n1*obj.getdenominator();
			d2=obj.getdenominator()*n2;
			Fraction obj2(d1,d2);
			return obj2;
		}
		Fraction Multiply(Fraction &obj){
			int n1,n2,d1,d2;
			char ch;
			cout<<"enter a fraction to add: ";
			cin>>n1>>ch>>n2;
			d1=obj.getnumerator()*n1;
			d2=obj.getdenominator()*n2;
			Fraction obj2(d1,d2);
			return obj2;
		}
		Fraction Divide(Fraction &obj){
			int n1,n2,d1,d2;
			char ch;
			cout<<"enter a fraction to add: ";
			cin>>n1>>ch>>n2;
			d1=obj.getnumerator()*n2;
			d2=obj.getdenominator()*n1;
			Fraction obj2(d1,d2);
			return obj2;
		}
		Fraction reduce(Fraction &obj)
		{
			int i,s1,s2;
			for(i=1;i<=99;i++)
			{
				if(obj.getnumerator()%i==0 && obj.getdenominator()%i==0)
				{
					s1=obj.getnumerator()/i;
					s2=obj.getdenominator()/i;
				}
			}
			Fraction obj3(s1,s2);
			return obj3;
		}
		void Display()
		{
			cout<<numerator<<"/"<<denominator;
		}
};
int main()
{
	cout<<"Enter a fraction to evaluate: ";
	int n1,n2,choice;
	char ch;
	cin>>n1>>ch>>n2;
	if(ch=='/')
	{
	Fraction obj(n1,n2);
	Fraction obj2,obj3;
	cout<<"1.Add\n2.Subtract\n3.Multiply\n4.Divide\nEnter your choice:";
	cin>>choice;
	switch(choice){
	
		case 1:
		{
	obj2=obj.Add(obj);
		obj3=obj2.reduce(obj2);
	obj3.Display();
	break;
		}
		case 2:
		{
	obj2=obj.Subtract(obj);
		obj3=obj2.reduce(obj2);
	obj3.Display();
	break;
		}
		case 3:
		{
	obj2=obj.Multiply(obj);
		obj3=obj2.reduce(obj2);
	obj3.Display();
	break;
		}
		case 4:
		{
	obj2=obj.Divide(obj);
	obj3=obj2.reduce(obj2);
	obj3.Display();
	break;
		}
	}
}
}
