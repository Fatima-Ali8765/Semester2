#include <iostream>
#include <string.h>
using namespace std;
int main()
{
	char word[100];
	int n;
	cout<<"Enter the number of times you want to enter a word:";
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cout<<"Enter a word: ";
		cin>>word;
		if(strlen(word)==7)
		{
			cout<<"Number: ";
			for(int j=0;j<=7;j++)
			{
				if(j==3)
				cout<<"-";
				else
				{
				if(word[j]=='A' || word[j]=='a')
				cout<<0;
				if(word[j]=='C' || word[j]=='D' ||word[j]=='c' || word[j]=='d')
				cout<<1;
				if(word[j]=='E' || word[j]=='e')
				cout<<2;
				if(word[j]=='G' || word[j]=='H'|| word[j]=='g' || word[j]=='h')
				cout<<3;
				if(word[j]=='L' || word[j]=='l')
				cout<<4;
				if(word[j]=='M' || word[j]=='N' || word[j]=='O' || word[j]=='m' ||word[j]=='n' || word[j]=='o')
				cout<<5;
				if(word[j]=='P' || word[j]=='p'||word[j]=='Q' || word[j]=='q'||word[j]=='R' || word[j]=='r')
				cout<<6;
				if(word[j]=='T' || word[j]=='t' ||word[j]=='S'||word[j]=='s')
				cout<<7;
				if(word[j]=='U' || word[j]=='u' ||word[j]=='v' || word[j]=='V'||word[j]=='W' || word[j]=='w')
				cout<<8;
				if(word[j]=='X' || word[j]=='x'||word[j]=='Y' || word[j]=='y'||word[j]=='Z' || word[j]=='z')
				cout<<9;
			}
			}
		}
		else
		{
			for(int j=0;j<=7;j++)
			{
				if(j==3)
				cout<<"-";
			else
			{
			
				if(word[j]=='A' || word[j]=='a')
				cout<<0;
				if(word[j]=='C' || word[j]=='D' ||word[j]=='c' || word[j]=='d')
				cout<<1;
				if(word[j]=='E' || word[j]=='e')
				cout<<2;
				if(word[j]=='G' || word[j]=='H'|| word[j]=='g' || word[j]=='h')
				cout<<3;
				if(word[j]=='L' || word[j]=='l')
				cout<<4;
				if(word[j]=='M' || word[j]=='N' || word[j]=='O' || word[j]=='m' ||word[j]=='n' || word[j]=='o')
				cout<<5;
				if(word[j]=='P' || word[j]=='p'||word[j]=='Q' || word[j]=='q'||word[j]=='R' || word[j]=='r')
				cout<<6;
				if(word[j]=='T' || word[j]=='t' ||word[j]=='S'||word[j]=='s')
				cout<<7;
				if(word[j]=='U' || word[j]=='u' ||word[j]=='v' || word[j]=='V'||word[j]=='W' || word[j]=='w')
				cout<<8;
				if(word[j]=='X' || word[j]=='x'||word[j]=='Y' || word[j]=='y'||word[j]=='Z' || word[j]=='z')
				cout<<9;
			}
			}
		}
	}
}
