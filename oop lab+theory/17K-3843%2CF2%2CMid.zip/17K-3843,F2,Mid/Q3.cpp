#include <iostream>
using namespace std;
class Student{
	protected:
		string Name;
		int Student_Number,Average_Marks;
	public:
		Student(string nme="",int num=0,int ave=0)
		{
			Name=nme;
			Student_Number=num;
			Average_Marks=ave;
		}
};
class Seminar_Enrolment:public Student{
	protected:
		const int Min_Marks;
	public:
		Seminar_Enrolment(string nme="",int num=0,int ave=0):Student(nme,num,ave),Min_Marks(60){
		}
		int Check_Marks()
		{
			if(Average_Marks>=Min_Marks)
			return 1;
		}
}; 
