#include<iostream>
using namespace std;
class phonum{
	private:
		long long int num;
		long long int a,b,c;
	public:
		phonum(long long int x)	//parametrised constructor
		{
			num=x;
		}
		void areacode()
		{
			a=num/100000000;
		}
		void exchange()
		{
			b=(num%100000000)/10000;
		}
		void consume()
		{
			c=(num%100000000)%10000; 
		}
		long long int getarea()
		{
			return a;
		}
		long long int getexchange()
		{
			return b;
		}
		long long int getconsume()
		{
			return c;
		}
};
int main()
{
	long long int s;
	cout<<"Please enter Your no:";
	cin>>s;
	phonum nim(s);
	nim.areacode();
	nim.consume();
	nim.exchange();
	cout<<"Your area code is:"<<nim.getarea()<<endl;
	cout<<"Your exchange code is: "<<nim.getexchange()<<endl;
	cout<<"Your consumer code is: "<<nim.getconsume();
}
