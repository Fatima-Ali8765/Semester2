#include <iostream>
#include <cstring>
using namespace std;
class Sales{
	private:
		int Quantity,SaleID;
		string ItemName;
	public:
		Sales(){
			SaleID=23990;
			Quantity=23;
			ItemName="Black Box";
		}//default constructor
		Sales(int x,int y,string sen)
		{
			SaleID=x;
			Quantity=y;
			ItemName=sen;
		}//parametrized constructor
		int getqua()
		{
			return Quantity;
		}
		int getSaleID(){
			return SaleID;
		}
		string getItemName()
		{
			return ItemName;
		}
		void display()
		{
			cout<<"SaleID: "<<SaleID<<endl;
			cout<<"ItemName: "<<ItemName<<endl;
			cout<<"Quantity: "<<Quantity<<endl;
		}
		Sales(Sales &obj){
			cout<<"Copying items of previously constructed object"<<endl;
			SaleID=obj.SaleID;
			Quantity=obj.Quantity;
			ItemName=obj.ItemName;
		}//copy constructor
		~Sales()
		{
			cout<<endl<<"Freeing memory";
		}
};
	void displayd(Sales obj){
			cout<<"Items in new object: "<<endl;
			cout<<"SaleID: "<<obj.getSaleID()<<endl;
			cout<<"ItemName: "<<obj.getItemName()<<endl;
			cout<<"Quantity: "<<obj.getqua()<<endl;
		}
int main()
{
	int x,y;
	Sales i1;
	i1.display();
	string sen;
	cout<<"Enter the value of SaleID: ";
	cin>>x;
	cout<<"Enter the Item Name: ";
	cin>>sen;
	cout<<"Enter the Quantity: ";
	cin>>y;
	Sales i2(x,y,sen);
	i2.display();
	Sales i3=i2;
	displayd(i3);
}
