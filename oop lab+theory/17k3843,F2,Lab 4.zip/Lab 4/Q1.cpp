#include <iostream>
using namespace std;
const int m=100;
class ShopList{
	private:
		char q[m];
		int code_no[m],qty[m],price[m],total,count;
	public:
		ShopList(){	//default constructor
			code_no[m]=0;
			qty[m]=0;
			price[m]=0;
			total=0;
			count=0;
		}
		void Add_Items(){	//add items
			char v;
			int x,y,z;
			cout<<"Enter the code number of the item: ";
			cin>>x;
			cout<<"Enter the quantity of the item: ";
			cin>>y;
			cout<<"Enter the price of the item: ";
			cin>>v>>z;
			q[count]=v;
			code_no[count]=x;
			qty[count]=y;
			price[count]=z;
			count++;
		}
		void Del_items(){	//delete items
			int i,u;
			cout<<"Enter the code number of the item whose price needs to be deleted: ";
			cin>>u;
			for(i=0;i<u;i++)
			{
				if(code_no[i]==u)
				price[i]=0;
			}
		}
		void Display_tot(){	//display total price
			int k;
			for(k=0;k<count;k++)
			{
				total=total+price[k];
			}
			if(total!=0)
			cout<<"Total price of the entered items are: "<<q[m]<<total;
			else
			cout<<"No items yet to display.";
		}
		void display_data()	//display entered data
		{
			int l;
			if(count==0)
			cout<<"No items yet to display.";
			else
			{
			for(l=0;l<count;l++)
			{
				cout<<endl<<"Code Number of item "<<l+1<<" : "<<code_no[l];
				cout<<endl<<"Quantity of item "<<l+1<<" : "<<qty[l];
				cout<<endl<<"Price of item "<<l+1<<" : "<<q[l]<<price[l];
				cout<<"\n";
			}
			}
		}
		~ShopList()	//destructor
		{
			cout<<"Good Bye";
		}
};
int main()
{
	ShopList mil;
	int choice;
	do
	{
		cout<<endl<<"1. Add items";
		cout<<endl<<"2. Delete items";
		cout<<endl<<"3. Display total price of entered items";
		cout<<endl<<"4. Display entered items";
		cout<<endl<<"5. Exit";
		cout<<endl<<"Enter your choice number: ";
		cin>>choice;
		switch(choice)
		{
			case 1:
				mil.Add_Items();
				break;
			case 2:
				mil.Del_items();
				break;
			case 3:
				mil.Display_tot();
				break;
			case 4:
				{
				cout<<endl<<"List of entered items are: ";
				mil.display_data();
				break;
				}
			case 5:
				break;
		}
	}while(choice!=5);
}
