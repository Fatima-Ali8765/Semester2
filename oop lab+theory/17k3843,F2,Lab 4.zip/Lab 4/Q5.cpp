#include<iostream>
#include<string>
using namespace std;
class student{
	private:
		string name,roll_no;
		int semester;
		char section;
	public:
		student(string a,string b,int c,char d)	//parametrised constructor
		{
			name=a;
			roll_no=b;
			semester=c;
			section=d;
		}
		string get_name()
		{
			return name;
		}
		string get_roll_no()
		{
			return roll_no;
		}
		int get_semester()
		{
			return semester;
		}
		char get_section()
		{
			return section;
		}
};
int main()
{
	string n,r;
	int s;
	char sec;
	cout<<"Enter your name: ";
	cin>>n;
	cout<<"Enter your Roll no: ";
	cin>>r;
	cout<<"Enter your semester number: ";
	cin>>s;
	cout<<"Enter your section: ";
	cin>>sec;
	student obj(n,r,s,sec);	//parametrised constructor
	cout<<endl<<"Name: "<<obj.get_name();
	cout<<endl<<"Roll no: "<<obj.get_roll_no();
	cout<<endl<<"Semester: "<<obj.get_semester();
	cout<<endl<<"Section: "<<obj.get_section();
}
