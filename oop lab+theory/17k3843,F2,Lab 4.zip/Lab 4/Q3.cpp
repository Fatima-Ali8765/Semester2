#include <iostream>
using namespace std;
class Distance{
	private:
		int distance_feet,distance_metres;
	public:
		Distance(){	//defaultconstructor
		}
		void input(){
			int x,y;
			cout<<"Enter distance in metres: ";
			cin>>x;
			cout<<"Enter distance in feet: ";
			cin>>y;
			distance_feet=y;
			distance_metres=x;
		}
		void displaymet(){	//display data
		cout<<"Distance in metres: "<<distance_metres<<endl;
		cout<<"Distance in feet: "<<distance_feet;
		}
		~Distance()	//destructor
		{
			cout<<endl<<"Allocating free space in the object";
		}
};
int main()
{
	Distance bmi;
	bmi.input();
	bmi.displaymet();
}
