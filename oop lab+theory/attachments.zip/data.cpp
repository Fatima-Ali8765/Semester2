#include <iostream>
#include<fstream>

using namespace std;

int main()
{   char data[100];
	ofstream file;
	file.open("new.dat",ios::out|ios::app);
	ifstream myfile;
	myfile.open("stu.dat");
	
	while(!myfile.eof())
	{
		myfile>>data;
		file<<data;
	}
myfile.close();
file.close();	
	
}
