#include <iostream>
#include<fstream>


using namespace std;

int main()
{
	char data[100];
	fstream myfile;
	myfile.open("file.bin",ios::out|ios::app|ios::binary);
	cout<<"Writing to a file"<<endl;
	cout<<"enter your name"<<endl;
	cin>>data;
	myfile.write((char *)data,100);
    myfile.seekg(0,ios::beg);

	while(!myfile.eof())
	{
		myfile.read((char *)data,100);
	    
	}
	
	myfile.close();

}


