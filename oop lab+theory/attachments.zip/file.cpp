#include<iostream>
#include<fstream>
#include<conio.h>
#include<stdlib.h>
#include<stdio.h>

using namespace std;

class student
{
	public:
		int roll;
		char name[15],f_name[20];
		void put()
		{
		//	clrscr();
			fstream file;
			cout<<"enter roll number"<<endl;
			cin>>roll;
			cout<<"enter name"<<endl;
			cin>>name;
			file.open("stu.dat",ios::out|ios::app);
			if(file.is_open())
			{
			
//			file<<roll<<endl;
//			file<<name<<endl;
file.write((char *)this,sizeof(student));
}
else
{
	cout<<"unable to open file"<<endl;
}
			file.close();
			
			
		}
		void get()
		{
			int temp;
			cout<<"enter roll number:"<<endl;
			cin>>temp;
			fstream file;
			file.open("stu.dat");
			if(file.is_open())
			{
			
			
			file.seekg(0,ios::beg);
			while(file.read((char *)this,sizeof(student)))
			{
				if(roll==temp)
				{
					cout<<roll;
					cout<<name;
				}
			}}
			else
			{
				cout<<"unable to open file"<<endl;
			}
			file.close();
			
		}
};
int main ()
{ student s;
	int i;
	cout<<"Enter your Choice: \n 1:Read \n2.Write \n 3.Exit"<<endl;
	cin>>i;

	
	switch(i)
	{
		case 1:
			s.get();
			break;
		case 2:
			s.put();
			break;
		case 3:
			exit(0);
			
		default:
			cout<<"wrong choice \n";
		
	}
}
