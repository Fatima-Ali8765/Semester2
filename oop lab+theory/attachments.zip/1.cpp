#include <iostream>
#include<fstream>
#include<stdlib.h>
#include<stdio.h>

using namespace std;

int main()
{
	char data[100];
	fstream myfile;
	myfile.open("afile.dat",ios::out|ios::app|ios::in);
	cout<<"Writing to a file"<<endl;
	cout<<"enter your name"<<endl;
	cin>>data;
	myfile<<data<<endl;
	
	cout<<"enter your age:"<<endl;
	cin>>data;
	myfile<<data<<endl;
	ofstream file;
	file.open("new.dat",ios::app);
	myfile.seekg(0,ios::beg);
	while(!myfile.eof())
	{
		myfile>>data;
		file<<data;
	}
	file.close();
	myfile.close();
//	
//	ifstream mfile;
//	mfile.open("afile.dat");
//	cout<<"reading from file"<<endl;
//	char c;
//	while(mfile.get(c))
//	{
//	//	mfile>>c;
//	cout<<c<<endl;
//		
//	}
////	mfile>>data;
////	cout<<data<<endl;
////	mfile>>data;
////	cout<<data<<endl;
////	mfile>>data;
////	cout<<data<<endl;
////	mfile>>data;
////	cout<<data<<endl;
////	mfile>>data;
////	cout<<data<<endl;
////	mfile>>data;
////	cout<<data<<endl;
////	mfile.close();
////	
//	
//	
//	
//	
}


