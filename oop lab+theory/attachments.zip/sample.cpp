#include <iostream>
#include <fstream>
using namespace std;
int main()
{
	char data[100];
	int x,y;
//	ofstream outfile;
//	outfile.open("afile.dat",ios::out | ios::app);
//	cout<<"Writing to the file"<<endl;
//	cout<<"Enter your name: ";
//	cin.getline(data,100);
//	outfile<<data<<endl;
//	cout<<"Enter your age: ";
//	cin>>data;
//	cin.ignore();
//	outfile<<data<<endl;
//	outfile.close();
	ifstream infile;
	infile.open("afile.dat");
	cout<<"Reading data from the file"<<endl;
	infile.seekg(0,ios::end);
	cout<<"Size:"<<infile.tellg();
	return 0;
}
