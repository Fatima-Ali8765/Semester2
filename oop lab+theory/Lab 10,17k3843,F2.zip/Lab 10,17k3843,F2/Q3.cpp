#include<iostream>
#include<fstream>
using namespace std;
class Person{
	private:
		char name[25];
		int age;
	public:
		void Get()
		{
				ofstream outfile;
		outfile.open("D://person.bin",ios::out | ios::app);
			Person obj;
			cout<<"Enter your name: ";
			cin.getline(name,25);
			cout<<"Enter age: ";
			cin>>age;
			outfile.write((char*)&obj,sizeof(obj));
		}
		void Show()
		{
			ifstream infile;
			infile.open("D://person.bin",ios::in|ios::app);
			Person obj;
			infile.read((char*)&obj,sizeof(obj));
			cout<<"Name: "<<name<<endl;
			cout<<"Age: "<<age<<endl;
		}
};
int main()
{
	Person person1;

	person1.Get();
	person1.Show();
	return 0;
}
