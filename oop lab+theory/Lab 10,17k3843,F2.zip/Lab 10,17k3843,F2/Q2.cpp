#include <iostream>
#include <fstream>
using namespace std;
int main()
{
	string data,var;
	char logic;
	ofstream file1;
	file1.open("File1data.txt");
	cout<<"Enter your data: ";
	while(logic!='N')
	{
		cin>>data;
		file1<<data<<endl;
		cout<<"Do you want to enter more data(Y/N)?";
		cin>>logic;
	}
	file1.close();
	ofstream file2;
	ifstream file3data("File1data.txt");
	file2.open("copiedinfo.txt");
	while(!file3data.eof())
	{
		getline(file3data,var);
		file2<<var<<endl;
	}
	file2.close();
	file3data.close();
}
