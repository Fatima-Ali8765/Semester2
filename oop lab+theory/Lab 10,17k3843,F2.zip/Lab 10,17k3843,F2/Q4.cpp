#include<iostream>
#include<fstream>
#include<conio.h>
#include<stdlib.h>
#include<stdio.h>

using namespace std;

class Participant
{
	private:
		int ID;
		char name[100];
		float score;
	public:
		void setscore(float sc){score=sc;
		}
		void setname(char n[100])
		{for(int i=0;i<100;i++)
		name[i]=n[i];
		}
		void setid(int id){ID=id;
		}
float getscore()
{return score;
}
string getname(){return name;
}
int getid(){return ID;
}
		void Input()
		{
			fstream file;
			cout<<"enter ID"<<endl;
			cin>>ID;
			cout<<"enter name"<<endl;
			cin>>name;
			cout<<"enter score"<<endl;
			cin>>score;
			file.open("participant.dat",ios::out|ios::app);
			if(file.is_open())
			{
			
file.write((char *)this,sizeof(Participant));
}
else
{
	cout<<"unable to open file"<<endl;
}
			file.close();
			
			
		}
		void Output()
		{
			int temp;
			cout<<"enter ID:"<<endl;
			cin>>temp;
			fstream file;
			file.open("participant.dat");
			if(file.is_open())
			{
			
			
			file.seekg(0,ios::beg);
			while(file.read((char *)this,sizeof(Participant)))
			{
				if(ID==temp)
				{
					cout<<ID<<endl;
					cout<<name<<endl;
					cout<<score<<endl;
				}
			}}
			else
			{
				cout<<"unable to open file"<<endl;
			}
			file.close();
			
		}
		void Max()
		{
		Participant obj2,obj3,obj;
		int count=0;
		fstream file;
		file.open("participant.dat");
		if(file.is_open())
			{
			file.seekg(0,ios::beg);
			while(file.read((char *)this,sizeof(obj)))
		{
				if(count==0)
				{
				count++;
				obj2.setid(ID);
				obj2.setname(name);
				obj2.setscore(score);
				}
			else
				{
				obj3.setid(ID);
				obj3.setname(name);
				obj3.setscore(score);
				}
		}
			}
			else
			{
				cout<<"unable to open file"<<endl;
			}
			if(obj3.getscore()>obj2.getscore())
				{
					cout<<obj3.getid()<<endl;
					cout<<obj3.getname()<<endl;
					cout<<obj3.getscore()<<endl;					
				}
				if(obj2.getscore()>obj3.getscore())
				{
					cout<<obj2.getid()<<endl;
					cout<<obj2.getname()<<endl;
					cout<<obj2.getscore()<<endl;
					
				}
			file.close();
		}
};
int main ()
{ Participant p1,p2,outpart;
cout<<"Enter data for first participant: \n";
p1.Input();
cout<<"Enter data for second participant: \n";
p2.Input();
cout<<"Participant info to search: \n";
outpart.Output();
cout<<"Participant with Maximum score: \n";
outpart.Max();	
}
