#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
int main()
{
	char variable[100];
	ofstream file1;
	file1.open("chat.txt",ios::out|ios::app);
	cout<<"Enter your data: ";
	cin>>variable;
	file1<<variable;
	cout<<"Length of string: "<<strlen(variable)<<endl;
	file1.close();
	ifstream readfile("chat.txt");
	char character;
	cout<<"Character by character print: \n";
	while(readfile.get(character))
	cout<<character<<endl;
}
