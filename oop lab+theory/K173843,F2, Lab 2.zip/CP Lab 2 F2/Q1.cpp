//draws a rectangle using functions
#include <stdio.h>
#include <iostream>
using namespace std;
void draw_solid_line(int size,char symbol);
void draw_hollow_line(int size,char symbol);
void draw_rectangle(int len, int wide,char symfr);

int main(void) {
 int length, width;
 char sym;
 cout<<"Enter length and width of rectangle >";
 cin>>length>>width;
 cout<<"Enter Symbol for the frame >";
 cin>>sym;

 draw_rectangle(length, width, sym);

 system("pause");
 return 0;
}
void draw_solid_line(int size,char symbol) {
int o;
for(o=1;o<=size;o++)
cout<<symbol;
}
void draw_hollow_line(int size,char symbol) {
int x;
cout<<symbol;
for(x=1;x<=size-2;x++)
cout<<" ";
cout<<symbol;
}
void draw_rectangle(int len, int wide,char symfr) {
 int i;
 draw_solid_line(wide,symfr);
 cout<<endl;

if (len > 2) {
 for (i=1; i<=len - 2; i++)
 {
  draw_hollow_line(wide,symfr);
  cout<<endl;
 }
 }
 draw_solid_line(wide,symfr);
 cout<<endl;
}
