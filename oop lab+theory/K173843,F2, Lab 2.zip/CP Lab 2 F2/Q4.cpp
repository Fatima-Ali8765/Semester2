#include <iostream>
using namespace std;
int is_prime(int s)
{
	int i,flag=0;
	for(i=2;i<=s/2;++i)
	{
		if(s%i==0)
		{
			flag=1;
			break;
		}
	}
	if(flag==0)
	return 1;
}
int main()
{
	int x;
	cout<<"prime factors between 2 and 100 are"<<endl;
	for(x=2;x<=100;x++)
	{
		if(is_prime(x)!=0)
		cout<<x<<" ";
	}
}
