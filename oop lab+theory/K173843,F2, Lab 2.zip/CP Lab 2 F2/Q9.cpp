#include <iostream>
using namespace std;
void rev_ele(int *sen,int n)
{
	int temp,k=0;
	while(k<n)
	{
		temp=*(sen+k);
		*(sen+k)=*(sen+n-1);
		*(sen+n-1)=temp;
		k++;
		n--;
	}
}
int main()
{
	int i,n,*c;
	cout<<"Enter the number of elements for the array: ";
	cin>>n;
	int arr[n];
	cout<<"Enter the elements for the array: "<<endl;
	for(i=0;i<n;i++)
	{
		cout<<"Enter element number "<<i+1<<" ";
		cin>>arr[i];
	}
	cout<<"Elements of array before reverse: "<<endl;
	for(i=0;i<n;i++)
	{
		cout<<arr[i]<<" ";
	}
	c=arr;
	rev_ele(c,n);
	cout<<endl<<"Elements of array after reverse: "<<endl;
	for(i=0;i<n;i++)
	{
		cout<<arr[i]<<" ";
	}
	
}
