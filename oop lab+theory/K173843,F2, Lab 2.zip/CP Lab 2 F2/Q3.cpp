#include <iostream>
using namespace std;
int perfect_Square(int value)
{
	int k,logic=1;
	for(k=1;k<=value;k++)
	{
		if(value==k*k)
		return logic;
	}
}
int main()
{
	int i,n1,n2,y=0;
	cout<<"Enter end values of an interval(integer values) > ";
	cin>>n1>>n2;
	cout<<"perfect squares between "<<n1<<" and "<<n2<<" are"<<endl;
	for(i=n1;i<=n2;i++)
	{
		y=perfect_Square(i);
		if(y==1)
		cout<<i<<" ";
	}
}
