#include <iostream>
#include <math.h>
using namespace std;
int rec_rev(int num,int length)
{
	if(length==0)
	return num;
	else
	return ((num%10*pow(10,length-1))+rec_rev(num/10,--length));
}
int main()
{
	int j,q,len=0;
	cout<<"Enter a positive integer number >";
	cin>>j;
	q=j;
	while(q!=0)
	{
		q/=10;
		len++;
	}
	q=rec_rev(j,len);
	cout<<q;
}
