#include <iostream>
using namespace std;
int main()
{
	int *p=new int[10];
	int *q=new int[10];
	int temp,i,j,var;
	cout<<"Enter 10 values to sort: ";
	for(i=0;i<10;i++)
	cin>>p[i];
	for(i=0;i<10;i++)
	q[i]=p[i];
	for(i=1;i<10;i++)
	{
		var=q[i];
		j=i-1;
		while(j>=0 && q[j]>var)
		{
			q[j+1]=q[j];
			j=j-1;
		}
		q[j+1]=var;
	}
	cout<<"Sorted array in ascending order: "<<endl;
	for(i=0;i<10;i++)
	cout<<q[i]<<",";
	for(i=1;i<10;i++)
	{
		var=q[i];
		j=i-1;
		while(j>=0 && q[j]<var)
		{
			q[j+1]=q[j];
			j=j-1;
		}
		q[j+1]=var;
	}
	cout<<"Sorted array in descending order: "<<endl;
	for(i=0;i<10;i++)
	cout<<q[i]<<",";
}
