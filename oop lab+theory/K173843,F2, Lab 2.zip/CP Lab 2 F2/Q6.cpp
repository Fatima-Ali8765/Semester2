#include <iostream>
using namespace std;
void time(int x)
{
	int h,m,s;
	h=x/3600;
	m=(x%3600)/60;
	s=(x%3600)%60;
	cout<<h<<" hour, "<<m<<" minutes and "<<s<<" seconds";
}
int main()
{
	int n;
	cout<<"Enter the time in seconds: ";
	cin>>n;
	time(n);
}
