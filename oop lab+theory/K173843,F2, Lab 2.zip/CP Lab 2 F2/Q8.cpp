#include <iostream>
using namespace std;
int countdigits(int x,int u)
{
	if(x==0)
	return u;
	else
	return countdigits(x/10,u+1);
}
int main()
{
	int i,n,j=0;
	cout<<"Enter an integer ";
	cin>>n;
	i=countdigits(n,j);
	cout<<i<<" Digits";
}
