#include <iostream>
using namespace std;
void readlen_wid(int *a,int *b)
{
	cout<<"Enter the length of rectangle: ";
	cin>>*a;
	cout<<"Enter the width of rectangle: ";
	cin>>*b;
	return ;
}
void are_per(int lk,int wk)
{
	cout<<"The area of rectangle is: "<<lk*wk<<endl;
	cout<<"The perimeter of rectangle is: "<<2*(lk+wk);
	return ;
}
int main()
{
	int l,w;
	readlen_wid(&l,&w);
	are_per(l,w);
}
