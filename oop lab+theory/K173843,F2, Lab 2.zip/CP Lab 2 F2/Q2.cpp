#include <iostream>
using namespace std;
void divisors(int *t,int x,int *q)
{
	int i=1,j=0;
	while(i<=x)
	{
	if(x%i==0)
	{
		*(t+j)=i;
		j++;
	}
	i++;
	}
	*q=j;
	return ;
}
int main()
{
	int *i,n,j,q;
	cout<<"Enter an integer >";
	cin>>n;
	i=new int(n);
	divisors(i,n,&q);
	cout<<"divisors of "<<n<<" are"<<endl;
	for(j=0;j<q;j++)
	{
		cout<<*(i+j)<<" ";
	}
}
