#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
class Product{
	private:
		long long int barcode;
		string name;
	public:
		Product(long long int bar=0,string nm=""):barcode(bar),name(nm)
		{
		}
		void setCode(long long int x){
		barcode=x;	
		}
		long long getCode(){
		return barcode;	
		}
		void setName(string ty){
			name=ty;
		}
		string getName(){
			return name;
		}
		void scanner(){
			cout<<"\nBarcode: ";
			cin>>barcode;
			cout<<"\nName: ";
			cin>>name;
		}
		void printer(){
			cout<<"\nBarcode: ";
			cout<<barcode;
			cout<<"\nName: ";
			cout<<name;
		}
};
class PrepackedFood:public Product
{
	private:
		float priceperuni;
	public:
		PrepackedFood(float pri=0,long long int k=0,string var=""):
		Product(k,var),priceperuni(pri)
		{
		}
		void setPrice(float val){priceperuni=val;}
		float getPrice(){return priceperuni;}
		void scanner()
		{Product::scanner();
		cout<<"Price per unit: ";
		cin>>priceperuni;
		}
		void printer()
		{cout<<"\nPrepacked food";
		Product::printer();
		cout<<fixed<<setprecision(2)<<"\nPrice per unit: "<<priceperuni<<endl;
		}
};
class FreshFood:public Product{
	private:
		float weight;
		float current_price_per_kilo;
	public:
		FreshFood(float w=0,float currentperkilo=0,long long int k=0,string var=""):
		Product(k,var),weight(w),current_price_per_kilo(currentperkilo)	
		{
		}
		void setweight(float wi){weight=wi;}
		float getweight()
		{
			return weight;
		}
		void setprice(float pal){current_price_per_kilo=pal;}
		float getprice(){
			return current_price_per_kilo;
		}
		void scanner()
		{cout<<"Freshfood: ";
		Product::scanner();
		cout<<"Weight(kilo): ";
		cin>>weight;
		cout<<"Price/kilo: ";
		cin>>current_price_per_kilo;
		}
		void printer()
		{Product::printer();
		cout<<fixed<<setprecision(2)<<"\nPrice per kilo: "<<current_price_per_kilo<<"\nWeight: "<<weight<<"\nTotal: "<<current_price_per_kilo*weight<<endl;
		}
};
int main()
{
	Product pw1(142345,"Flour"),pw2;	//object for product
	pw1.printer();
	pw2.setName("Sugar");
	pw2.setCode(654321);
	pw2.printer();
	PrepackedFood paf1(0.28,78956,"Beans"),paf2;	//object for prepacked food
	paf1.printer();
	cout<<"\nInput data of prepacked product: ";
	paf2.scanner();
	paf2.printer();
	FreshFood put1(1.78,1.69,454578,"Grapes"),put2;	//object for fresh food
	put1.printer();
	cout<<"\nInput data of fresh product: ";
	put2.scanner();
	put2.printer();
}
