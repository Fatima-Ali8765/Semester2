#include <iostream>
using namespace std;
class Person{
	private:
	int age;
	protected:
	string name;
	public:
	Person(int a,string n):
	age(a),name(n){
	}
	void dis()
	{
		cout<<"Name: "<<name<<endl;
		cout<<"Age: "<<age<<endl;
	}
};
class Employee{
	private: 
	int empId; 
	protected: 
	float salary;
	public:
	Employee(int eid,float sly):
	empId(eid),salary(sly){
	}
	void dis1()
	{
	cout<<"Employee ID: "<<empId<<endl;
	cout<<"Salary: "<<salary<<endl;	
	}
};
class Manager:public Person, public Employee{
	private:
	string type;
	public:
	Manager(int a,string n,int id,float sal,string tpe):
	Person(a,n),Employee(id,sal),type(tpe){
	}	
	void dis2()
	{
		cout<<"Type: "<<type<<endl;
	}
};
class ITManager: public Manager{
	private: 
	int noOfPersons; 
	public:
	ITManager(int a,string n,int id,float sal,string tpe,int num):
	Manager(a,n,id,sal,tpe),noOfPersons(num){
	}		
	void Display()
	{
		dis();
		dis1();
		dis2();
		cout<<"No of Employees: "<<noOfPersons;                     
	}
};
int main()
{
	int empID,age,noOfPersons;
	float salary;
	string name,type;
	cout<<"Enter the details in the following order: \n1.age\n2.name\n3.employee id\n4.salary\n5.type\n6.no of prople employed\n";
	cin>>age;
	cin>>name;
	cin>>empID;
	cin>>salary;
	cin>>type;
	cin>>noOfPersons;
	ITManager obj(age,name,empID,salary,type,noOfPersons);
	obj.Display();
	return 0;
}
