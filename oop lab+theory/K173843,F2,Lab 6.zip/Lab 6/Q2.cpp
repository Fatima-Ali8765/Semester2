#include <iostream>
using namespace std;
class Employee{
	private:
		string last_name;
		int number;
	public:
		void set_data()
		{
			cout<<"Enter last name: ";
			cin>>last_name;
			cout<<"Enter number: ";
			cin>>number;
		}
		void place_data() const
		{
			cout<<"\n Last Name: "<<last_name;
			cout<<"\n Number: "<<number;
		}
};
class Manager:public Employee{
	private:
		string title;
		float club_dues;
	public:
		void set_data()
		{
			Employee::set_data();
			cout<<"Enter title: ";
			cin>>title;
			cout<<"Enter golf club dues: ";
			cin>>club_dues;
		}
		void place_data()const
		{
			Employee::place_data();
			cout<<endl<<"Title: "<<title;
			cout<<endl<<"Golf club dues: "<<club_dues;
		}
};
class Scientist:public Employee{
	private:
		string title,publication;
	public:
		void set_data()
		{
			Employee::set_data();
			cout<<"Enter title: ";
			cin>>title;
			cout<<"Enter publication: ";
			cin>>publication;
		}
		void place_data()const
		{
			Employee::place_data();
			cout<<endl<<"Title: "<<title;
			cout<<endl<<"Publication "<<publication;
		}
};
class Laborer:public Employee{
	private:
		string title;
	public:
		void set_data()
		{
			Employee::set_data();
			cout<<"Enter title: ";
			cin>>title;
		}
		void place_data()const
		{
			Employee::place_data();
			cout<<endl<<"Title: "<<title;
		}
};
int main()
{
	cout<<"Enter the number of your position: \n1.Manager\n2.Scientist\n3.Laborer\n";
	int c,n1,n2,n3;
	cin>>c;
	switch(c)
	{
		case 1:
			{
				Manager obj;
				obj.set_data();
				cout<<"Data of manager: ";
				obj.place_data();
			}
		case 2:
			{
				Scientist obj;
				obj.set_data();
				cout<<"Data of Scientist: ";
				obj.place_data();
			}
		case 3:
			{
				Laborer obj;
				obj.set_data();
				cout<<"Data of Laborer: ";
				obj.place_data();
			}
	}
}
