#include <iostream>
#include <typeinfo>
using namespace std;
class Employee{
	private:
		string First_name,last_name,social_security_number;
	public:
		Employee(string fn,string ln,string ssn)
		{
			setfn(fn);
			setln(ln);
			setssn(ssn);
		}
		void setfn(string fn)
		{
			First_name=fn;
		}
		void setln(string ln)
		{
			last_name=ln;
		}
		void setssn(string ssn)
		{
			social_security_number=ssn;
		}
		string getfn()
		{
			return First_name;
		}
		string getln()
		{
			return last_name;
		}
		string getssn()
		{
			return social_security_number;
		}
		virtual double earning()=0;
		virtual void print()
		{
			cout<<getfn()<<" "<<getln();
			cout<<"\n Social security number: "<<getssn();
		}
};
class Salariedemployees: public Employee{
	private:
		double salary;
	public:
		Salariedemployees(string fn,string ln,string ssn,double sal):Employee(fn,ln,ssn){
		setweeklysalary(sal);
		}
		void setweeklysalary(double sal)
		{
			salary=sal;
		}
		double getsal()
		{
			return salary;
		}
	virtual double earning()
	{
		return getsal();
	}
	virtual void print()
	{
		cout<<"\nsalaried employee: ";
		Employee::print();
		cout<<"\n Salary: "<<earning();
	}
};
class hourlyemployees:public Employee{
	private:
		double wage,hours;
	public:
		hourlyemployees(string fn,string ln,string ssn,double wa,double h):Employee(fn,ln,ssn){
			setwage(wa);
			sethours(h);
		}
		void setwage(double Wage)
		{wage=Wage;}
		void sethours(double h)
		{hours=h;}
		virtual double earning()
		{if(gethours()<=40)
		return gethours()*getwage();
		else
		return getwage()*40+(gethours()-40)*getwage()*1.5;
		}
		double getwage()
		{return wage;}
		double gethours()
		{return hours;}
		virtual void print()
		{
			cout<<"hourly employee: ";
		Employee::print();
		cout<<"\n Salary: "<<earning();
		}
};
class commissionemployees:public Employee{
	private:
		double commissionRate,grossSales;
	public:
		commissionemployees(string fn,string ln,string ssn,double sales,double rate):Employee(fn,ln,ssn){
			setGrossSales(sales);
			setcommissionRate(rate);
		}
		void setGrossSales(double sales)
		{	grossSales=sales;
		}
		void setcommissionRate(double rate)
		{commissionRate=rate;
		}
		double getsales(){return grossSales;}
		double getrate(){return commissionRate;}
		virtual double earning()
		{
			return getsales()*getrate();
		}
		virtual void print()
		{
			cout<<"\nCommision employee:";
		Employee::print();
		cout<<"\n gross sales: "<<getsales();
		cout<<"\n commission rate: "<<getrate();
		}
};
class basesalarypluscommisionemployees:public commissionemployees{
	private:
		double basesalary;
	public:
		basesalarypluscommisionemployees(string fn,string ln,string ssn,double sales,double rate,double salary):commissionemployees(fn,ln,ssn,sales,rate){
			setbasesal(salary);
		}
		void setbasesal(double salary){
			basesalary=salary;
		}
		double getbasesal()
		{return basesalary;}
		virtual double earning()
		{return getbasesal()+commissionemployees::earning();}
		virtual void print()
		{
			cout<<"\nBasecommission employee:";
			commissionemployees::print();
		}
};
int main()
{
	Salariedemployees employee1("Bob","Lane","234-98-5043",800.00);
	hourlyemployees employee2("Kim","Juon","876-27-3395",10.5,40);
    commissionemployees employee3("Sue","Lee","818-39-1206",10000,0.06);
	basesalarypluscommisionemployees employee4("Anton","Lewis","321-34-6690",5000,0.04,300);
	Employee *e1,*e2,*e3,*e4;
	e1=&employee1;
	e2=&employee2;
	e3=&employee3;
	e4=&employee4;
	cout<<"upcast:\n";
	e1->print();
	cout<<"\nearned: "<<e1->earning();
	cout<<endl;
	e2->print();
	cout<<"\nearned: $"<<e2->earning();
	cout<<endl;
	e3->print();
	cout<<"\nearned: $"<<e3->earning();
	cout<<endl;
	e4->print();
	cout<<"\nearned: $"<<e4->earning();
	cout<<endl;
	cout<<"\ndowncast\n";
	
	basesalarypluscommisionemployees *derivedptr=static_cast<basesalarypluscommisionemployees *>(e1);
	derivedptr->print();
	cout<<"\nearned: $"<<derivedptr->earning();
	cout<<endl;
	basesalarypluscommisionemployees *derivedptr2=static_cast<basesalarypluscommisionemployees *>(e2);
	derivedptr2->print();
	cout<<"\nearned: $"<<derivedptr2->earning();
	cout<<endl;
	basesalarypluscommisionemployees *derivedptr3=static_cast<basesalarypluscommisionemployees *>(e3);
	derivedptr3->print();
	cout<<"\nearned: $"<<derivedptr3->earning();
	cout<<endl;
	basesalarypluscommisionemployees *derivedptr4=static_cast<basesalarypluscommisionemployees *>(e4);
	derivedptr4->print();
	cout<<"\nearned: $"<<derivedptr4->earning();
	cout<<endl;
}
