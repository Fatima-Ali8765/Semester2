#include <iostream>
using namespace std;
template <class Y>
void bubblesort(Y a[],int size)
{
   int i, j;
   Y temp;
   for (i=0;i<size-1; i++)
   
for (j=0;j<size-i-1;j++) 
		
	if (a[j] > a[j+1])
	{
		temp=a[j+1];
		a[j+1]=a[j];
		a[j]=temp;
	}
		
	for(i=0;i<size;i++)
	cout<<a[i]<<endl;
}
int main()
{
	int a1[7]={7,5,4,3,9,8,6};
	int size=7;
	cout<<"Sorted array for int: \n";
	bubblesort(a1,size);
	float b1[5]={4.3, 2.5, -0.9, 100.2, 3.0};
	int size2=5;
	cout<<"Sorted array for float: \n";
	bubblesort(b1,size2);
}
