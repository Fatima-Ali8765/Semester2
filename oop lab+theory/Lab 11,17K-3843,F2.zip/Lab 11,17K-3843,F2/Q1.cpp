#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdlib>
using namespace std;
class Inventory{
private:
	char description[100];
	float rate_per_unit;
	int total_units,item_code;
	public:
		Inventory(){
		}
		void setdesc(char d[])
		{for(int i=0;i<100;i++)
		description[i]=d[i];
		}
		string getdesc()
		{return description;
		}
		void setrpu(float r)
		{rate_per_unit=r;
		}
		float getrpu()
		{return rate_per_unit;
		}
		void setun(int u)
		{total_units=u;
		}
		int getun()
		{return total_units;
		}
		void setcode(int c)
		{item_code=c;
		}
		int getcode()
		{return item_code;
		}
		void enterdata()
		{
			fstream file;
			cout<<"Enter item code: ";
			cin>>item_code;
			cout<<"Enter description: ";
			cin>>description;
			cout<<"Enter rate per unit: ";
			cin>>rate_per_unit;
			cout<<"Enter total units: ";
			cin>>total_units;
			file.open("inventory.dat",ios::out|ios::app);
			if(file.is_open())
			{
			file.write((char *)this,sizeof(Inventory));
			}
			else
			cout<<"Unable to open file."<<endl;
			file.close();
		}
		void details(int code)
	{
			fstream file;
			file.open("inventory.dat");
			if(file.is_open())
			{
			
			file.seekg(0,ios::beg);
			while(file.read((char *)this,sizeof(Inventory)))
			{
				if(item_code==code)
				{
			cout<<item_code<<" ";
			cout<<description<<" ";
			cout<<rate_per_unit<<" ";
			cout<<total_units;
				}
			}}
			else
			{
				cout<<"unable to open file"<<endl;
			}
			file.close();
			
		
	}
void details()
		{
			fstream file;
			file.open("inventory.dat");
			if(file.is_open())
			{
			
			file.seekg(0,ios::beg);
			while(file.read((char *)this,sizeof(Inventory)))
			{
			cout<<item_code<<" ";
			cout<<description<<" ";
			cout<<rate_per_unit<<" ";
			cout<<total_units;
			cout<<endl;
			}}
			else
			{
				cout<<"unable to open file"<<endl;
			}
			file.close();			
		}
		void update()
{
		fstream updatefile("inventory.dat",ios::binary|ios::in|ios::out);
		cout<<"enter item code: ";
		int icode;
		cin>>icode;
		Inventory inventory;
updatefile.read((char*)&inventory,sizeof(inventory));
		if(inventory.getcode()==icode)
		{
		int pos=updatefile.tellg()-sizeof(inventory);
		updatefile.seekp(pos,ios::beg);
		inventory.setun(20);
		updatefile.write((char*)&inventory,sizeof(inventory));
		}
		
		updatefile.close();
}	


};

int main()
{
	int code,choice;
	Inventory obj[5],obje;
		cout<<"\n1.Enter info\n2.Enter item code to search for item \n3.Update stock\n4.Display all records";
		cin>>choice;
	switch(choice)
	{
		case 1:
			{for(int i=0;i<5;i++)
			obj[i].enterdata();
			break;
			}
		case 2:
			{
			cout<<"Enter code: ";
			cin>>code;
			obje.details(code);
			break;
			}
			case 3:
			{
	obje.update();
				break;
			}
			case 4:
				{
				obje.details();
				break;
				}
	}
	return 0;
}
