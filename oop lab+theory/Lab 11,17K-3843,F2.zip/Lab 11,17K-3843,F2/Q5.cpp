#include <iostream>
using namespace std;
template<class G,class H>
void f(G a,H b)
{
	cout<<a*b<<endl;
}
template<class X,class Y,class Z>
void f(X a,Y b,Z c)
{
	cout<<a*b*c<<endl;
}
int main()
{
	f(50,12);
	f(23,12,6);
	f(13.5,15.6);
	f(0.5,2.5,4.25);
}
