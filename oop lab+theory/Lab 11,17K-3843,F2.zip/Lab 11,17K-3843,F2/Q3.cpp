#include <iostream>
#include <cstring>
using namespace std;
template<class X,class Y>
class Myclass{
	public:
	X element;
	Y element2;
	Myclass(X element,Y element2)
	{
	this->element = element;
	this->element2 = element2;
	}
	void print()
	{
		cout<<element+element2<<endl;
	}
};
template<>
class Myclass<char*,char*>
{
	public:
	char element[100],element2[100];	
	Myclass(char* ele,char* ele2)
	{
		for(int i=0;i<100;i++)
		element[i]=*(ele+i);		
		for(int i=0;i<100;i++)
		element2[i]=*(ele2+i);
	}
	void print()
	{
		cout<<strcat(element,element2)<<endl;
	}
};
int main()
{
	Myclass<int,double>idob(10,0.23);
	Myclass<char*,char*>cob("Now","Then");
	idob.print();
	cob.print();
}
