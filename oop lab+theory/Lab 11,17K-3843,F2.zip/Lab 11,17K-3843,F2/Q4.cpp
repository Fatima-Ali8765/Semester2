#include <iostream>
using namespace std;
class arraysum{
	private:
		int sum;
		double sum1;
	public:
		arraysum():sum(0),sum1(0){
		}
		template<class X>
		X iSum(X arr[],X size)
		{
			for(int i=0;i<size;i++)
			sum=sum+arr[i];
			return sum;
		}
		template<class X,class Y>
		X dSum(X arr[],Y size)
		{
			for(int i=0;i<size;i++)
			sum1=sum1+arr[i];
			return sum1;
		}
};
int main()
{
	arraysum vali,vald;
	int size1,size2;
	cout<<"Enter size of integer type array: ";
	cin>>size1;
	cout<<"Enter size of  double type array: ";
	cin>>size2;
	int arr1[size1];
	double arr2[size2];
	cout<<"Enter values to be stored in int array: ";
	for(int i=0;i<size1;i++)
	cin>>arr1[i];
	
	cout<<"Enter values to be stored in double array: ";
	for(int i=0;i<size2;i++)
	cin>>arr2[i];
	cout<<"Sum of values in int array: "<<vali.iSum(arr1,size1)<<endl;
	cout<<"Sum of value in double array: "<<vald.dSum(arr2,size2)<<endl;
}
