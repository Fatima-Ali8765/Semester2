#include <iostream>
#include <string>
using namespace std;
class Employee{
	private:
		char* fname;
		string lname;
		int msalary;
	public:
		void set_firstname(char* fq){
			fname=fq;
		}
		void set_lastname(string lq){
			lname=lq;
		}
		void set_monthlysalary(int mq){
			if(mq<0)
			mq=0;
			else
			msalary=mq;
		}
		char* get_firstname(){
			return fname;
		}
		string get_lastname(){
			return lname;
		}
		int get_msa(){
			return msalary;
		}
		int inc()
		{
			int y;
			y=msalary*0.1+msalary;
			return y;
		}
		void display(){
			cout<<endl<<"First Name: "<<get_firstname();
			cout<<endl<<" Last Name: "<<get_lastname();
			cout<<endl<<" Yearly salary: "<<get_msa()*12;
		}
		void display_inc(){
			cout<<endl<<"After 10% increase: ";
			cout<<endl<<"First Name: "<<get_firstname();
			cout<<endl<<" Last Name: "<<get_lastname();
			cout<<endl<<" Yearly salary: "<<inc()*12;
		}
};
int main()
{
	Employee emp1,emp2;
	char* fme=new char;
	string lnme;
	int msal;
	cout<<"Enter the first name, last name and monthly salary of first employee: ";
	cin>>fme;
	cin>>lnme;
	cin>>msal;
	emp1.set_firstname(fme);
	emp1.set_lastname(lnme);
	emp1.set_monthlysalary(msal);
	emp1.display();
	emp1.display_inc();
	cout<<endl<<"Enter the first name, last name and monthly salary of second employee: ";
	cin>>fme;
	cin>>lnme;
	cin>>msal;
	emp2.set_firstname(fme);
	emp2.set_lastname(lnme);
	emp2.set_monthlysalary(msal);
	emp2.display();
	emp2.display_inc();
}
