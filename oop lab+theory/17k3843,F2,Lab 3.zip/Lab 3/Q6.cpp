#include <iostream>
using namespace std;
class Vehicle{
	private:
		int year,speed;
		string manufacturer;
	public:
		Vehicle(int x)	//value taken from main function
		{
			speed=x;	//assigning value in speed
		}
		void accelerate()
		{
			speed=speed+5;	//incrementing speed
		}
		void brake()
		{
			speed=speed-5;	//decrementing speed
		}
		int getspeed()
		{
			return speed;
		}
};
int main()
{
	int i,j,k;
	cout<<"Enter speed of Rickshaw: ";
	cin>>i;
	cout<<"Enter speed of Bike: ";
	cin>>j;
	Vehicle Rickshaw(i),Bike(j);
	cout<<"After accelerating 5 times "<<endl;
	for(k=1;k<=5;k++)	//displaying speed after each increment
	{
	Rickshaw.accelerate();
		cout<<endl<<"Speed of Rickshaw: "<<Rickshaw.getspeed();
	Bike.brake();
		cout<<endl<<"Speed of Bike: "<<Rickshaw.getspeed();
	}
	cout<<endl<<"After braking twice: "<<endl;
	for(k=1;k<=2;k++)	//displaying speed after each decrement
	{
		Rickshaw.brake();
		cout<<endl<<"Speed of Rickshaw: "<<Rickshaw.getspeed();
		Bike.brake();
		cout<<endl<<"Speed of Bike: "<<Rickshaw.getspeed();
	}
}
