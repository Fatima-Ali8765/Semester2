#include <iostream>
using namespace std;
class Rectangle{
	private:
		float length,width;
		public:
		void area(){
			cout<<"Area: "<<get_length()*get_width()<<endl;}	//calculating perimeter
		void perimeter(){
			cout<<"Perimeter: "<<2*(get_length()+get_width());}	//calculating perimeter
		void set_length(float lw)	//assigning length
		{
			if(lw>0.0 && lw<20.0)
			length=lw;
			else
			length=1;
		}
		void set_width(float ww)	//assigning width
		{
			if(ww>0.0 && ww<20.0)
			width=ww;
			else
			width=1;
		}
		float get_length()	//returning value of length
		{
			return length;}
		float get_width()	//returning value of width
		{
			return width;}	
};
int main()
{
	Rectangle rte;
	float x,y;
	cout<<"Enter the length of the rectangle: ";
	cin>>x;
	cout<<"Enter the width of the rectangle: ";
	cin>>y;
	rte.set_length(x);	//calling functions in public
	rte.set_width(y);
	rte.area();
	rte.perimeter();
}
