#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
class Game
{
	private:
	int n1,n2,sc1,sc2;
	public:
	Game()	//default constructor
		{
			sc1=0;
			sc2=0;
		}
	void valueassign(int s,int y)	//assigning values
	{		
	n1=s;
	n2=y;
	}
	void number1()	//output of number 1
	{
		cout<<endl<<"Number1: "<<n1;
	}	
	void number2()	//output of number 2
	{
		cout<<endl<<"Number2: "<<n2;
	}
	void display()
	{
		if(n1==n2)	//comparison of n1 and n2
		{
		cout<<endl<<"Enemy got hit by your team"<<endl;
		sc1=sc1+1;
		}
		else
		{
		cout<<endl<<"You got hit by the enemy team"<<endl;
		sc2=sc2+1;
		}
	}
	void display1()	//display final results
	{
		if(sc1>sc2)
		cout<<"Game Over! You won";
		else if(sc1<sc2)
		cout<<"Game Over! Enemy's team won";
		else
		cout<<"Game Over! It's a tie";
	}
};
int main()
{
	Game player;
	int i,s,x,y;
	srand((unsigned)time(0));
	s=(rand()%10)+1;	//number of turns 
	cout<<"Total No. Of Players in your team: "<<s<<endl;
	for(i=1;i<=s;i++)
	{
		cout<<endl<<"Pair of numbers:";
		x=(rand()%6)+1;
		y=(rand()%6)+1;
		player.valueassign(x,y);
		player.number1();
		player.number2();
		player.display(); //display results of every return
	}
	player.display1();
}
