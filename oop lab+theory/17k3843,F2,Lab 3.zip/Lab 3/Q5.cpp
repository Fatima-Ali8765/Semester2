#include<iostream>
using namespace std;
class Coffeejava{
	private:
		float sb,lb,mb,total,costa;		
		int number,n1;
		int count1,count2,count3;
	public:
			Coffeejava()	//default constructor
			{
				count1=0;
				count2=0;
				count3=0;
			}
			void set(int x)	//Number of boxes assigned in variable number and n1
			{
				number=x;
				n1=number;
			}
			void box()
			{
				if(number>=20)	//comparison for Large box
				{
					count1=number/20; //Increment no. for large boxes
					number=number%20;	
				}
				if(number>=10)	//Comparison for medium box
				{
					count2=number/10;	//Increment no. for medium boxes
					number=number%10;
				}
				while(number>0)	//comparison for small box
				{
				if(number<10)
				{
					count3=count3+1;	//Increment no. for small boxes
					number=number-5;
				}
				}
			}
			int getx()	//return of no. of large boxes
			{
				return count1;
			}
			int gety()
			{
				return count2;	//return of no. of medium boxes
			}
			int getz()
			{
				return count3;	//return of no. of small boxes
			}
			void large()
			{
				lb=1.80*count1; //calculation of cost of large boxes
			}
			float getlb()
			{
				return lb;	//return of cost of large boxes
			}
			void medium()
			{
				mb=1.00*count2;	//calculation of cost of medium boxes
			}
			float getmb()
			{
				return mb;	//return of cost of medium boxes
			}
			void small()
			{
				sb=0.60*count3;	//calculation of cost of small boxes
			}
			float getsb()
			{
				return sb;	//return of cost of small boxes
			}
			void cost()
			{
				costa=n1*5.50;	//cost of order
			}
			float getcost()
			{
				return costa;	//return of cost of order
			}	
			void display()	//function to display results
			{
			cout<<"The cost of Order: $"<<getcost()<<endl;
			cout<<"Boxes Used: "<<endl;
			cout<<getx()<<" Large - $";
			cout<<getlb()<<endl;
			cout<<gety()<<" Medium - $";
			cout<<getmb()<<endl;
			cout<<getz()<<" Small - $";
			cout<<getsb()<<endl;
			total=getsb()+getlb()+getcost()+getmb();
			cout<<"Your total cost is: $"<<total;
			}
};
int main()
{
	Coffeejava obj;	//	assigning class
	int num;
	cout<<"Enter number: ";
	cin>>num;
	obj.set(num);
	cout<<"Number of Bags Ordered: "<<num<<endl;
	obj.cost();
	obj.box();
	obj.large();
	obj.medium();
	obj.small();
	obj.display();
}

