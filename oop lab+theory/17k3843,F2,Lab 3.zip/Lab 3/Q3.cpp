#include<iostream>
using namespace std;
class Invoice{
	private:
		int quantity;
		float price_per_item;
		string number,description;
	public:
		void set_quantity(int c)	//setting description
		{
			if(c<0)
			quantity=0;
			else
			quantity=c;
		}
		void set_price(float d)	//setting price of item
		{
			if(d<0)	
			price_per_item=0;
			else
			price_per_item=d;
		}
		void set_number(string k)	//setting the number
		{
			number=k;
		}
		void set_description(string j)	//setting the description
		{
			description=j;
		}
		float getinvoiceamount()	//calculating and returning the value of invoice
		{
		float ans;
		ans=quantity*price_per_item;
		return ans;
		}
		string get_number()	//returning the number of item
		{
			return number;
		}
		string get_description()	//returning the description of item
		{
			return description;
		}
		int get_quantity()	//returning the quantity of item
		{
			return quantity;
		}
		float get_price_per_item()	//returning the value of price per item
		{
			return price_per_item;
		}
		void display()	//displaying entered items
		{
			cout<<endl<<"Number: "<<get_number();
			cout<<endl<<"Description: "<<get_description();
			cout<<endl<<"Quantity: "<<get_quantity();
			cout<<endl<<"Price per item: "<<get_price_per_item();
			cout<<endl<<"Invoice: "<<getinvoiceamount();
		}
};
int main()
{
	Invoice obj;	//declaring a class
	string n,d;
	int q;
	float price;
	cout<<"Enter the number: "<<endl;
	getline(cin,n);
	cout<<"Enter the description: "<<endl;
	getline(cin,d);
	cout<<"Enter quantity: ";
	cin>>q;
	cout<<"Enter the price per item: ";
	cin>>price;
	obj.set_description(d);	//function call
	obj.set_quantity(q);
	obj.set_number(n);
	obj.set_price(price);
	obj.display();
}
